package com.kodingnext.passwordkeeper.sqlite;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

//Setup the database
@Database(entities = {ModelPassword.class}, version = 1, exportSchema = false)
public abstract class RepositoryPassword extends RoomDatabase {
    public abstract DaoAccess daoAccess();
}
